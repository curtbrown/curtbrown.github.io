$('.card').click(function () {
    $('.card').toggleClass('applyflip');
}.bind(this));
$('.card2').click(function () {
    $('.card2').toggleClass('applyflip');
}.bind(this));
$('.card3').click(function () {
    $('.card3').toggleClass('applyflip');
}.bind(this));
$('.card4').click(function () {
    $('.card4').toggleClass('applyflip');
}.bind(this));
